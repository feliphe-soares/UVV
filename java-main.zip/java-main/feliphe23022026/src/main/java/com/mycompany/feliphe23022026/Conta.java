/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.feliphe23022026;

/**
 *
 * @author alunolab13
 */
public class Conta {
    private double saldo, limite;
    private int agencia, numero;
    
    public double getSaldo(){
        return saldo;
    }
    
    public double getLimite() {
        return limite;
    }
    
    void setAgencia(int agencia){
        this.agencia = agencia;
    }
    
    int getAgencia(){
        return agencia;
    }
    
    void setNumero(int numero){
        this.numero = numero;
    }
    
    int getNumero(){
        return numero;
    }
    
    public Conta() { 
    }
        public Conta(int agencia, int numero, double valor, double limite){
        this.agencia = agencia;
        this.numero = numero;
        saldo += valor;
        this.limite = limite;
    }
   
    public void creditar (double valor){
        saldo += valor;
    }
    public void debitar (double valor){
        if(valor > (this.saldo + this.limite)){
            System.out.println("Valor de débito maior que o limite.");
        }
        else{
            saldo -= valor;
        }        
    } 
    
    public void transferir (Conta destino, double valor){
        debitar(valor);
        destino.creditar(valor);
    }
   
  
   
}
