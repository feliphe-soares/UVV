/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.feliphe12022026;
import java.util.Scanner;
/**
 *
 * @author alunolab13
 */
public class Principal {

    public static void main(String[] args) {
        
        Conta s1 = new Conta();
        Scanner sc = new Scanner(System.in);
        System.out.print("Digite o credito: R$");
        s1.creditar(sc.nextDouble());
        System.out.print("Digite o debito: R$");
        s1.debitar(sc.nextDouble());
        System.out.println("Saldo total = R$" + s1.getSaldo());
    }
}
