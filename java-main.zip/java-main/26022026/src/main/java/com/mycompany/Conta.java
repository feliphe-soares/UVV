/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany;

/**
 *
 * @author alunolab13
 */
public class Conta {

    private double saldo, limite;
    private int agencia, numero;
    
    public double getSaldo(){
        return saldo;
    }
    
    public double getLimite() {
        return limite;
    }
    
    void setAgencia(int agencia){
        this.agencia = agencia;
    }
    
    int getAgencia(){
        return agencia;
    }
    
    void setNumero(int numero){
        this.numero = numero;
    }
    
    public double getSaldoDisponivel(){
        return saldo + limite;
    }
    
    int getNumero(){
        return numero;
    }
    Conta(){
    }                                                                                                                                 
     public Conta(int agencia, int numero, double saldoInicial, double limite) {
        this.saldo = saldoInicial;
        this.limite = limite;
        this.agencia = agencia;
        this.numero = numero;
    }

    public void creditar (double valor){
    saldo += valor;
    }
    /*public void debitar (double valor){
        if(valor > getSaldoDisponivel()){
            System.out.println("Valor de débito maior que o limite.");
        }
        else{
            saldo -= valor;
        }        
    }*/
    
    public boolean debitar(double valor){
        if (valor <= getSaldoDisponivel()){
            saldo -= valor;
            return true;
        }
        else{
            System.out.println("Valor de debito maior que o limite.");
            return false;
        }
    }
    
    public boolean transferir (Conta destino, double valor){
        if(valor <= getSaldoDisponivel()){
            debitar(valor);
            destino.creditar(valor);
            return true;
        }
        else{
            System.out.println("Valor de tranferencia maior que o saldo em conta.");   
            return false;
        }
    }
   
  
   
}